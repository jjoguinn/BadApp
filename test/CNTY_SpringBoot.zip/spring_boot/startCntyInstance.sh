#!/bin/sh

port=${1}
instance=${2}

/cygdrive/c/Oracle/java/jdk1.8.0_51/bin/java -DSERVER_PORT=${port} -Dspring.cloud.config.profile=local -Duse.cl.properties=true -jar ../gradle_build/libs/cnty-boot-3.2.0.jar

